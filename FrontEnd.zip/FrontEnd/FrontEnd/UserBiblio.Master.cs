﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FrontEnd
{
	public partial class UserBiblio : System.Web.UI.MasterPage
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			// No se requiere lógica del lado del servidor para el cambio de tema.
			// Esto se maneja con JavaScript en el cliente.
		}
	}
}